package express.demo.service;

import express.demo.model.User;
import express.demo.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserService {

    private final UserRepository userRepository;

    @Autowired
    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    // Get all users from the repository
    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    // Create a new user and save it to the repository
    public User createUser(User user) {
        return userRepository.save(user);
    }
}
